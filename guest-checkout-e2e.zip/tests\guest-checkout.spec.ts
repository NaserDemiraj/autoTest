import { test, expect } from '@playwright/test';

const BASE_URL = process.env.BASE_URL || 'https://demo.opencart.com/';

// This test assumes the demo site structure; adjust selectors for your target store.

test('guest checkout full flow', async ({ page }) => {
  // Open storefront
  await page.goto(BASE_URL);
  await expect(page).toHaveURL(/demo.opencart.com/);

  // Add first product to cart (assuming product list has Add to Cart buttons)
  const firstAdd = page.locator('text=Add to Cart').first();
  await expect(firstAdd).toBeVisible();
  await firstAdd.click();

  // Open cart
  await page.locator('a:has-text("shopping cart")').first().click();
  await expect(page).toHaveURL(/route=checkout\/cart/);
  await expect(page.locator('h1')).toContainText(/Shopping Cart/i);

  // Proceed to checkout
  await page.locator('a:has-text("Checkout")').click();
  await expect(page).toHaveURL(/route=checkout\/checkout/);

  // Choose Guest Checkout option
  await page.locator('input[name="account"][value="guest"]').check();
  await page.locator('input[value="Continue"]').nth(0).click();

  // Fill billing details
  await page.fill('input[name="firstname"]', 'Test');
  await page.fill('input[name="lastname"]', 'User');
  await page.fill('input[name="email"]', 'test.user+' + Date.now() + '@example.com');
  await page.fill('input[name="telephone"]', '1234567890');
  await page.fill('input[name="address_1"]', '123 Testing Ave');
  await page.fill('input[name="city"]', 'Testville');
  await page.fill('input[name="postcode"]', '12345');
  await page.selectOption('select[name="country_id"]', '223'); // United States (may vary)
  await page.selectOption('select[name="zone_id"]', '3613');
  await page.locator('input[value="Continue"]').nth(1).click();

  // Delivery method continue
  await page.locator('input[value="Continue"]').nth(2).click();

  // Agree to terms if present and continue to payment
  const agree = page.locator('input[name="agree"]');
  if (await agree.count() > 0) {
    await agree.check();
  }
  await page.locator('input[value="Continue"]').nth(3).click();

  // Confirm order (may be a button with text 'Confirm Order')
  const confirm = page.locator('input[value="Confirm Order"], button:has-text("Confirm Order")');
  await expect(confirm).toBeVisible();
  await confirm.click();

  // Verify order confirmation
  await expect(page.locator('h1')).toContainText(/Your Order Has Been Placed|Your order has been placed/i);
});
